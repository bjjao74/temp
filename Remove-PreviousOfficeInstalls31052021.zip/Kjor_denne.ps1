﻿cd C:\Temp\Remove-PreviousOfficeInstalls
.\Remove-PreviousOfficeInstalls.ps1 -Remove2016Installs $true -Force $true